<?php 
include 'conexion.php';
if (!empty($_POST)): 

		$nombre		= (empty($_POST["nombre"])) ? "nombre" : $_POST["nombre"] ;
		$email  	= (empty($_POST["email"])) ? "email" : $_POST["email"] ;
		$mensaje 	= (empty($_POST["message"])) ? "message" : $_POST["message"] ;
		$numero 	= (empty($_POST["numero"])) ? "numero" : $_POST["numero"] ;

		
		$to      = 'monica@capptus.com';
		$subject = "Comentario de $nombre";
		$message = "Me llamo: $nombre, mi email es: $email y $mensaje mi numero es $numero";
		$headers = 'From: info@wowyourbrand.com.mx' . "\r\n" .
    				'Reply-To: eddelacr.1000@gmail.com' . "\r\n" .
    				'X-Mailer: PHP/' . phpversion();

		mail($to, $subject, $message,$headers);
		$sql = "INSERT INTO contacto (nombre, correo, mensaje, numero)
				VALUES ('$nombre', '$email', '$mensaje', '$numero')";
		mysqli_query($conn, $sql);

	endif;
?>